/*
 * scope2.c
 *
 *  Created on: 30.10.2019
 *      Author: Jens
 */

float globalvar;

void modtest(void){
	globalvar = 2;
}


