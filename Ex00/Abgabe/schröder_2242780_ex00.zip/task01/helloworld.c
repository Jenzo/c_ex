/*
 * helloworld.c
 *
 *  Created on: 17.10.2019
 *      Author: Jens Schr�der
 */


#include <stdio.h>
#include <stdlib.h>

int main(void){
	// use standard print function from stdio.h file
	printf("Hello World\n");

	// return 0 for success exit code
	return 0;
}
