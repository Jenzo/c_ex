/*
 * move.hpp
 *
 *  Created on: 28.12.2019
 *      Author: Jens
 */

#ifndef MOVE_HPP_
#define MOVE_HPP_

/**
 * Helper struct to hold row and column index for a players move
 */
struct Move {
	int row, col;
};



#endif /* MOVE_HPP_ */
