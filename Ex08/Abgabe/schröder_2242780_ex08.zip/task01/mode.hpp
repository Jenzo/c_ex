/*
 * Mode.hpp
 *
 *  Created on: 18.12.2019
 *      Author: Jens
 */

#ifndef MODE_HPP_
#define MODE_HPP_

/**
 * Game Modes for ComputerPlayer
 */
enum Mode {
	RANDOM, MINIMAX
};

#endif /* MODE_HPP_ */
